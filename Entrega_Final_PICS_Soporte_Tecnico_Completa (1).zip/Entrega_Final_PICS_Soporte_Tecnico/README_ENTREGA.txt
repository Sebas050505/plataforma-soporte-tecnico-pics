================================================================================
ENTREGA FINAL — ENCUENTRO INSTITUCIONAL DE PROYECTOS PICS II-2026
Escuela Tecnológica Instituto Técnico Central (ETITC)
Facultad de Sistemas · Técnico Profesional en Computación
================================================================================

PROYECTO
--------
Plataforma Inteligente para la Gestión de Soporte Técnico

AUTOR
-----
Sebastian Yamith Manrique Godoy

PRESENTADO A / ASESORES
-----------------------
José Fernando Ruiz Quintana
Celio Gil Aros
Edwin Alberto Mendoza Mazo

FECHA
-----
Noviembre 2026

================================================================================
CONTENIDO DE ESTA CARPETA
================================================================================

1. Documento/
   Documento_Proyecto_PICS_Soporte_Tecnico.docx
   → Documento formal completo según plantilla oficial PICS (estructura APA/IEEE).
     Incluye: Introducción, Resumen, Abstract, Antecedentes, Justificación,
     Objetivos, Planteamiento del problema, Solución, Análisis crítico,
     Metodología, Herramientas, Desarrollo, Resultados, Conclusiones,
     Referencias y Anexos.

2. Presentacion/
   Presentacion_Final_PICS_Soporte_Tecnico.pptx
   → 14 diapositivas para la sustentación / exposición oral.
     Incluye logo institucional.

3. Poster/
   Poster_PICS_Soporte_Tecnico.pptx
   → Diseño final del póster para exhibición en la feria.
     Ya incluye el logo oficial de la ETITC.
     Espacio preparado en la esquina inferior derecha para el código QR.

4. Anexos/
   - Sprint_1_Plataforma_Soporte_Tecnico.docx          (documentación completa Sprint 1)
   - Pruebas sprint 2.docx
   - Pruebas sprint 3 - plan y evidencias.docx
   - Pruebas sprint 4 - plan y evidencias.docx
   - Pruebas sprint 5 - plan y evidencias.docx
   - Pruebas sprint 6 - plan y evidencias.docx         (si estaba)
   - Pruebas sprint 7 - plan y evidencias.docx
   - Diagrama_Entidad_Relacion_soporte_ia1.png
   - Diccionario_Base_Datos_soporte_ia1.docx
   - Gestion_Proyecto_Plataforma_Soporte_Tecnico.xlsx

5. Logo/
   logo_ETITC.png

================================================================================
CÓDIGO QR DEL PÓSTER (INSTRUCCIONES)
================================================================================

1. Crea un repositorio público en GitHub (recomendado) o una carpeta compartida
   en Google Drive / OneDrive con:
   - Este paquete completo
   - El código fuente (HTML, flujos n8n, scripts SQL)
   - Capturas o video corto de la demo

2. Genera el QR con el enlace del repositorio o de la carpeta compartida
   (usa qr-code-generator.com o similar).

3. Inserta la imagen PNG del QR en el póster (recuadro azul inferior derecho).

4. Exporta el póster a PDF en alta calidad para impresión.

Repositorio de referencia mencionado en la documentación del proyecto:
https://github.com/Sebas050505/plataforma-soporte-tecnico

================================================================================
NOTAS IMPORTANTES
================================================================================

- El ZIP original de cada sprint (Sprint6_entrega, Sprint7_entrega, etc.)
  contiene el código fuente completo, flujos n8n, scripts SQL y todas las
  capturas de evidencias. Se recomienda adjuntarlos también o subirlos al
  enlace del QR.

- Todos los planes de pruebas de los Sprints 3 a 7 reportan casos pasados
  (14/14 en Sprint 5, 8/8 en Sprint 4, etc.).

- El documento principal sigue la estructura exigida por la plantilla oficial
  de proyectos PICS.

Listo para entrega formal a través de Microsoft Teams (Proyectos PICS II-2026)
y para exhibición en la Sede Tintal (semana del 23 de noviembre de 2026).

================================================================================
