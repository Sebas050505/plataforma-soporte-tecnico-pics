ENTREGA FINAL — PROYECTOS PICS II-2026
Escuela Tecnológica Instituto Técnico Central (ETITC)
Facultad de Sistemas

Proyecto: Plataforma Inteligente para la Gestión de Soporte Técnico
Autor: Sebastian Yamith Manrique Gofoy
Asesores: José Fernando Ruiz Quintana, Celio Gil Aros, Edwin Alberto Mendoza Mazo

CONTENIDO DE ESTA CARPETA
========================

1. Documento/
   Documento_Proyecto_PICS_Soporte_Tecnico.docx
   → Documento formal completo según plantilla oficial (APA/IEEE).

2. Presentacion/
   Presentacion_Final_PICS_Soporte_Tecnico.pptx
   → Diapositivas para la sustentación / exposición (14 slides).

3. Poster/
   Poster_PICS_Soporte_Tecnico.pptx
   → Diseño final del póster para exhibición.
   → Ya incluye el logo oficial de la ETITC.
   → Espacio inferior derecho para el código QR (ver instrucciones abajo).

4. Anexos/
   - Diagrama_Entidad_Relacion_soporte_ia1.png
   - Diccionario_Base_Datos_soporte_ia1.docx
   - Gestion_Proyecto_Plataforma_Soporte_Tecnico.xlsx
   - Pruebas sprint 6 - plan y evidencias.docx
   - Pruebas sprint 7 - plan y evidencias.docx

5. Logo/
   logo_ETITC.png  (logo oficial institucional)

INSTRUCCIONES PARA EL CÓDIGO QR DEL PÓSTER
==========================================
1. Suba a Google Drive / OneDrive / GitHub un enlace que contenga:
   - La demo de la plataforma (o capturas + video corto)
   - El código fuente (HTML, flujos n8n, scripts SQL)
   - Este mismo paquete de documentación

2. Genere el código QR con cualquier generador gratuito:
   - https://www.qr-code-generator.com/
   - https://qr.io/
   - o la herramienta de Google Chart API

3. Descargue el QR como imagen PNG (recomendado tamaño 300x300 px o superior).

4. Abra Poster_PICS_Soporte_Tecnico.pptx e inserte la imagen del QR
   en el recuadro azul inferior derecho (reemplace el texto de instrucción).

5. Exporte a PDF en alta calidad para impresión del póster físico.

NOTA: El ZIP original "Sprint7_entrega" contiene el resto de evidencias,
flujos n8n, scripts SQL y capturas de todos los sprints. Se recomienda
adjuntarlo también o subirlo al enlace del QR.

Fecha de preparación: 21 de noviembre de 2026
